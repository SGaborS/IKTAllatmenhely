let menyhelyiMacskak = [new Macska("Molly","Ocicat",true,"2021-10-01","Félénk"),new Macska("Garfield","Ocicat",false,"2020-07-25","Félénk"),new Macska("Simba","Brit rövidszőrű",true,"2019-05-12","Energiadús"), new Macska("Sanyi","Burma",true,"2020-05-12","Játékos"), new Macska("Cammogó","Egyiptomi mau",false,"2022-08-20","Falánk")];

function insertTable() {
  let adminTable = document.querySelector(".adminTable");
  adminTable.innerHTML = "";
  for (let i = 0;i<menyhelyiMacskak.length;i++) {
    adminTable.innerHTML += '<tr><th scope="row">'+menyhelyiMacskak[i].getNev()+'</th><td>'+menyhelyiMacskak[i].getFajta()+'</td><td>'+menyhelyiMacskak[i].getNemText()+'</td><td>'+menyhelyiMacskak[i].getSzulNap()+'</td><td>'+menyhelyiMacskak[i].getDesc()+'</td><td><button class="delete" data-bs-toggle="modal" data-bs-target="#macskaTorolModal">Törlés</button><button value="'+i+'" class="edit" data-bs-toggle="modal" data-bs-target="#macskaHozzaadModal" onclick="insertData()">Módosítás</button></td></tr>'
  }
}

function insertSzulNap() {
  let szulnapEv = document.querySelector(".szulnap-ev");
  let szulnapHo = document.querySelector(".szulnap-ho");
  let szulnapNap = document.querySelector(".szulnap-nap");

  for(let i = 0;i<25;i++) {
    szulnapEv.innerHTML += '<option value="">'+(2000+i)+'</option>';
  }

  for(let i = 1;i<13;i++) {
    szulnapHo.innerHTML += '<option value="">'+(i<10?'0'+i:i)+'</option>';
  }

  for(let i = 1;i<32;i++) {
    szulnapNap.innerHTML += '<option value="">'+(i<10?'0'+i:i)+'</option>';
  }

}

function insertData() {
  let button = event.target;
  index = button.value;
  document.querySelector(".nev").value = menyhelyiMacskak[index].getNev();
  document.querySelector(".fajta").value = menyhelyiMacskak[index].getFajta();
  document.querySelector(".jellem").value = menyhelyiMacskak[index].getDesc();
  let nem = menyhelyiMacskak[index].getNem();
  if(nem) {
    document.querySelector(".him").checked = true;
  }
  else {
    document.querySelector(".nosteny").checked = true;
  }
  let szulnap = menyhelyiMacskak[index].getSzulNap().split("-");
  document.querySelector(".szulnap-ev").selectedIndex = parseInt(szulnap[0]) - 1999;
  document.querySelector(".szulnap-ho").selectedIndex = parseInt(szulnap[1]);
  document.querySelector(".szulnap-nap").selectedIndex = parseInt(szulnap[2]);
}

function clearForm() {
  let inputok = document.querySelectorAll(".form-clear");
  let radio = document.querySelectorAll(".form-uncheck");
  let szulNapok = document.querySelectorAll(".szul-nap");

  for(let i = 0;i<inputok.length;i++) {
    inputok[i].value="";
  }
  for(let i = 0;i<radio.length;i++) {
    radio[i].checked = false;
  }
  for(let i = 0;i<szulNapok.length;i++) {
    szulNapok[i].selectedIndex=0;
  }
}