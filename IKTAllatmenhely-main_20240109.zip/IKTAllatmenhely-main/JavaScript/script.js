function clear() {
  let menupontok = document.querySelectorAll(".menupont");

  for (let i = 0; i < menupontok.length; i++) {
    menupontok[i].style.display = "none";
  }
}

function fooldalMegjelenit() {
  clear();
  document.querySelector(".fooldal").style.display = "block";
  insertTable();
}

fooldalMegjelenit();
insertSzulNap();

let fooldal = document.querySelector(".fooldalGomb");
let macskak = document.querySelector(".macskakGomb");
let orokbefogadas = document.querySelector(".orokbefogadasGomb");

fooldal.addEventListener("click", function () {
  fooldalMegjelenit();
});
macskak.addEventListener("click", function () {
  clear();
  document.querySelector(".macskak").style.display = "block";
});
orokbefogadas.addEventListener("click", function () {
  clear();
  document.querySelector(".orokbefogadas").style.display = "block";
});




var availableTags = [
  "Molly",
  "Garfield",
  "Simba",
  "Sanyi",
  "Cammogó",
  "Bibi",
  "Alfonz",
  "Masni",
  "Eszmeralda",
  "Hím",
  "Nőstény",
  "Ocicat",
  "Brit rövidszúrű",
  "Burma",
  "Egyiptomi mau",
  "Házi macska",
  "Cymric",
  "Burmilla",
  "Sárga-fehér",
  "Fehér-barna",
  "Fehér-szürke",
  "Fehér-fekete",
  "Fehér-barna",
  "Fehér-sárga",
  "Félénk",
  "Energiadús",
  "Játékos",
  "Falánk",
  "Emberkedvelő",
  "Fürge",
  "Bújós",

];
$( "#tags" ).autocomplete({
  source: availableTags
});
